package it.unicam.cs.pa.jbudget097992.model;

public interface Account {

    String getId();
    void setId(String id);
    String getName();
    void setName(String name);
    double getBudget();
    void setBudget(double budget);
}
