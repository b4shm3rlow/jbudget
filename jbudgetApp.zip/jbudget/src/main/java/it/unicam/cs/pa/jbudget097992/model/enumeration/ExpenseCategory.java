package it.unicam.cs.pa.jbudget097992.model.enumeration;

public enum ExpenseCategory {
    RENT,
    BILLS,
    TAX,
    FOOD,
    HELT,
    SPORT_FITNESS,
    RELAX,
    HOLIDAY,
    ELECTRONICS,
    EDUCATION,
    CLOTHES,
    HOUSE_OUTDOOR,
    GIFT,
    OTHER

}
