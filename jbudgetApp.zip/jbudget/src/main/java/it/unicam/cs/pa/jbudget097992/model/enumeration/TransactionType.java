package it.unicam.cs.pa.jbudget097992.model.enumeration;

public enum TransactionType {
    EXPENSE,
    PROFIT
}
