package it.unicam.cs.pa.jbudget097992.model.enumeration;

public enum ProfitCategory {
    SALARY,
    PENSION,
    RENT,
    GIFT,
    RESALE,
    REFOUND,
    INVESTMENT,
    INVOICES,
    OTHER
}
